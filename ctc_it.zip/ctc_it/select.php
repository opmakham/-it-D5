<?php 
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_login']) && !isset($_SESSION['user_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: signin.php');
}

require ('connect.php');

// Initialize search variable
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Modify SQL query based on search input
$sql = 'SELECT * FROM tb_d5_67';

if (!empty($search)) {
    $sql .= " WHERE std_id LIKE '%$search%' OR f_name LIKE '%$search%' OR l_name LIKE '%$search%'";
}

$sql .= ';';

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo mysqli_num_rows($result);
} else {
    echo "EMPTY DATA";
}

$objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
?>

<head>
  <title>แสดงข้อมูล</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-image: url('444.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }
    
    

    .search-box {
      width: 100%;
    }
  </style>
</head>

<div class="container mt-3">
  <div class="search-container">
    <form method="GET" action="">
      <input type="text" class="form-control search-box" name="search" placeholder="ค้นหา..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
    </form>
  </div>

  <table class="table table-bordered">
    <thead class="table-dark">
      <tr>
        <th width="10">
          <div align="center">ลำดับ</div>
        </th>
        <th width="20">
          <div>รหัสนักศึกษา</div>
        </th>
        <th width="100">
          <div>คำนำหน้า</div>
        </th>
        <th width="100">
          <div>ชื่อ</div>
        </th>
        <th width="100">
          <div>สกุล</div>
        </th>
        <th width="100">
          <div>ชื่อเล่น</div>
        </th>
        <th width="100">
          <div>เพศ</div>
        </th>
        <th width="100">
          <div>แผกนวิชา</div>
        </th>
        <th width="100">
          <div>Profile</div>
        </th>
      </tr>
    </thead>
    <tbody>
      <?php
      $i = 1;
      while ($objResult = mysqli_fetch_array($objQuery)) {
        ?>
        <tr>
          <td>
            <div align="center"><?php echo $i; ?></div>
          </td>
          <td><?php echo $objResult["std_id"]; ?></td>
          <td><?php echo $objResult["n_title"]; ?></td>
          <td><?php echo $objResult["f_name"]; ?></td>
          <td><?php echo $objResult["l_name"]; ?></td>
          <td><?php echo $objResult["n_name"]; ?></td>
          <td><?php echo $objResult["sex"]; ?></td>
          <td><?php echo $objResult["DepartmentID"]; ?></td>
          <td align="center">
                            <a href="<?php echo $objResult["Profile"]; ?>">
                                <button type="button" class="btn btn-outline-danger">Profile</button>
                            </a>
                        </td>
        </tr>
        <?php
        $i++;
      }
      ?>
    </tbody>
  </table>

  <div style="text-align: center;">
    <a href="logout.php" class="btn btn-outline-danger">Logout</a>
  </div>
</div>

<?php
mysqli_close($conn); // ปิดฐานข้อมูล
?>
