<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประวัติส่วนตัว</title>
    <link rel="stylesheet" href="style.css">

  </head>
  <body style="background-image: url(Screenshot\ 2024-06-06\ 163124.png);">
    
    <div class="container-lg mt-3 border">.container-lg</div>
    <div class="container-fluid mt-3">
  <div class="row">
      <div class="col p-3 bg-primary text-white">หน้าหลัก</div>
      <div class="col p-3 bg-dark text-white">000</div>
      <div class="col p-3 bg-primary text-white">หน้าสุดท้าย</div>
    </div>

        
  
    <h1>แนะนำตัว</h1>
    <img src="รูป/me.jpg" alt="รูป/me.jpg"width="300" height="400">
    <h2>ชื่อ: ธนยศ พันธุ์เกิด</h2>
    <h2>ชื่อเล่น: มะขาม</h3>
    <h2>อายุ: 18</h2>
    <h2>กรุ๊ปเลือด: O</h2>
    <h4 style="color: red;">ว/ด/ป ของฉัน<h2>
    <h2>วันที่เกิด:13 กันยายน 2548</h2>
    <h4 style="color: red;">ที่อยู่<h2>
    <h2>-40/1 หมู่2 ต.โนนแดง อ.บ้านเขว้า จ.ชัยภูมิ </h2>
    <h4 style="color: red;">ช่องทางการติดต่อ</h4>
    <h2>Facebook: Tanayos punkerd</h2>
    <h2>Line: Tanayos punkerd</h2>
    <h2>เบอร์โทร: 0611174058</h2>
    <h2 style="color: red;">ข้อมูลส่วนตัว</h2>
    <h2>ชื่อบิดา: นายกิตติ พันธุ์เกิด อายุ57</h2>
    <h2>อาชีพ: รับราชการ เบอร์โทร: 0644643491</h2>
    <h2>ชื่อมารดา: นางไพรวัลย์ พันธุ์เกิด</h2>
    <h2>อาชีพ: รับราชการ เบอร์โทร: 0867118530</h2>
    <h2 = style="color: red;">งานอดิเรก</h2>
<h2>-เล่นเกม ฟังเพลง อ่านมังงะ</h2>
<h2 = style="color: red;">เรียนจบอยากทำอาชีพอะไร</h2>
<h2>-รับราชการ</h2>
   
</body>
</html>

