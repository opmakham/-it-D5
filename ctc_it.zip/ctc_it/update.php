<?php 

session_start();
require_once 'db.php';

// Redirect to signin if no admin session
if (!isset($_SESSION['admin_login'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
    header('location: signin.php');
    exit(); // Ensure script stops after redirect
}

require('connect.php');

// Check if a search term is provided
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Modify SQL query to include search functionality
$sql = "SELECT * FROM tb_d5_67";
if ($search) {
    $sql .= " WHERE std_id LIKE '%$search%' OR f_name LIKE '%$search%' OR l_name LIKE '%$search%' OR n_name LIKE '%$search%'";
}

$objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>อัพเดทข้อมูล</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(15deg, #667eea, #764ba2);
            padding-top: 40px;
            display: flex;
            background-image: url('gg.jpg');
            background-size: cover;
        }
        .search-container {
            display: flex;
            justify-content: center; /* Center horizontally */
            margin-bottom: 20px;
        }
        .search-form {
            display: flex;
            align-items: center;
            width: 100%;
            max-width: 600px; /* Set a maximum width */
        }
        .search-input {
            flex: 1; /* Make the input take up available space */
        }
        
    </style>
</head>
<body>
    <div class="container mt-3">
        <!-- Search form centered -->
        <div class="search-container">
            <form method="get" action="update.php" class="search-form">
                <input type="text" name="search" class="form-control search-input" placeholder="ค้นหาโดยรหัสนักศึกษา, ชื่อ, ชื่อเล่น หรือสกุล" value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-primary ms-2" type="submit">ค้นหา</button>
            </form>
        </div>

        <table class="table">
            <thead class="table-dark">
                <tr>
                    <th width="50">
                        <div align="center">No</div>
                    </th>
                    <th width="100">
                        <div align="center">รหัสนักศึกษา</div>
                    </th>
                    <th width="100">
                        <div align="center">คำนำหน้า</div>
                    </th>
                    <th width="100">
                        <div align="center">ชื่อ</div>
                    </th>
                    <th width="100">
                        <div align="center">สกุล</div>
                    </th>
                    <th width="100">
                        <div align="center">ชื่อเล่น</div>
                    </th>
                    <th width="100">
                        <div align="center">เพศ</div>
                    </th>
                    <th width="100">
                        <div align="center">เบอร์</div>
                    </th>
                    <th width="100">
                        <div align="center">อีเมล</div>
                    </th>
                    <th width="100">
                        <div align="center">แผกนวิชา</div>
                    </th>
                    
                    <th width="100">
                        <div align="center">Delete</div>
                    </th>
                    <th width="100">
                        <div align="center">Update</div>
                    </th>
                    <th width="100">
                        <div align="center">ข้อมูลส่วนตัว</div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($objResult = mysqli_fetch_array($objQuery)) {
                ?>
                    <tr>
                        <td>
                            <div align="center"><?php echo $i; ?></div>
                        </td>
                        <td><?php echo $objResult["std_id"]; ?></td>
                        <td><?php echo $objResult["n_title"]; ?></td>
                        <td><?php echo $objResult["f_name"]; ?></td>
                        <td><?php echo $objResult["l_name"]; ?></td>
                        <td><?php echo $objResult["n_name"]; ?></td>
                        <td><?php echo $objResult["sex"]; ?></td>
                        <td><?php echo $objResult["number"]; ?></td>
                        <td><?php echo $objResult["e_mail"]; ?></td>
                        <td><?php echo $objResult["DepartmentID"]; ?></td>
                        
                        <td align="center">
                            <a href="deletedata.php?std_id=<?php echo $objResult["std_id"]; ?>">
                                <button type="button" class="btn btn-outline-secondary">Delete</button>
                            </a>
                        </td>
                        <td align="center">
                            <a href="update2.php?std_id=<?php echo $objResult["std_id"]; ?>">
                                <button type="button" class="btn btn-outline-info">Update</button>
                            </a>
                        </td>

                        <td align="center">
                            <a href="<?php echo $objResult["Profile"]; ?>"><button type="button" class="btn btn-outline-danger">Profile</button></a>
                        </td>
                    </tr>
                <?php
                    $i++;
                }
                ?>
            </tbody>
        </table>
        <div style="text-align: center;">
            <a href="insert.php" class="btn btn-outline-info">Insert</a>
            <a href="logout.php" class="btn btn-outline-danger">Logout</a>
        </div>
        <?php
        mysqli_close($conn); // Close the database connection
        echo "<br><br>";
        ?>
    </div>
</body>
</html>
