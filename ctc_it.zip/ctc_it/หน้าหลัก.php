<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Alignment Example</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: flex-start;
            align-items: flex-start;
        }
        .menu-container {
            display: flex;
            gap: 10px; /* Space between the buttons */
            padding: 10px;
        }
        .menu-button {
            background-color: #007bff; /* Blue background */
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }
        .menu-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <div class="menu-container">
        <a href="update.php" class="menu-button">รายชื่อ</a>
        <a href="#" class="menu-button">หน้าหลัก</a> 
    </div>
</body>
</html>
