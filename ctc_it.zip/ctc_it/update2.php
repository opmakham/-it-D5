<?php
$update_ID = $_REQUEST['std_id'];
$std_id = $update_ID;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ข้อมูล</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(15deg, #667eea, #764ba2);
            padding-top: 40px;
            display: flex;
            background-image: url('gg.jpg');
            background-size: cover;
            
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 30px 30px 0px 0px rgba(0, 0, 0, 0.1);
            width: 70%;
            max-width: 500px;
        }
        .btn-submit {
            background-color: #764ba2;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;

        }
       
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center mb-4">แก้ข้อมูล</h2>
        <form action="updatedata.php?std_id=<?php echo $std_id; ?>" method="post" name="Employee">
            <div class="mb-3">
                <label for="std_id" class="form-label">รหัสนักศึกษา</label>
                <input type="text" class="form-control" id="std_id" name="std_id" value="<?php echo $std_id; ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="DepartmentID" class="form-label">แผนก</label>
                <select class="form-select" id="DepartmentID" name="DepartmentID">
                    <?php
                    require('connect.php');
                    $sql = 'SELECT DepartmentID FROM department;';
                    $objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
                    while ($objResult = mysqli_fetch_array($objQuery)) {
                    ?>
                        <option value="<?php echo $objResult["DepartmentID"]; ?>"><?php echo $objResult["DepartmentID"]; ?></option>
                    <?php
                    }
                    mysqli_close($conn);
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="n_title" class="form-label">คำนำหน้า</label>
                <input type="text" class="form-control" id="n_title" name="n_title">
            </div>
            <div class="mb-3">
                <label for="f_name" class="form-label">ชื่อ</label>
                <input type="text" class="form-control" id="f_name" name="f_name">
            </div>
            <div class="mb-3">
                <label for="l_name" class="form-label">สกุล</label>
                <input type="text" class="form-control" id="l_name" name="l_name">
            </div>
            <div class="mb-3">
                <label for="n_name" class="form-label">ชื่อเล่น</label>
                <input type="text" class="form-control" id="n_name" name="n_name">
            </div>
            <div class="mb-3">
                <label for="sex" class="form-label">เพศ</label>
                <input type="text" class="form-control" id="sex" name="sex">
            </div>
            <div class="mb-3">
                <label for="number" class="form-label">เบอร์</label>
                <input type="text" class="form-control" id="number" name="number">
            </div>
            <div class="mb-3">
                <label for="e_mail" class="form-label">อีเมล</label>
                <input type="text" class="form-control" id="e_mail" name="e_mail">
            </div>
            <div class="mb-3 text-center">
    <button type="submit" class="btn btn-submit d-grid justify-content-center">แก้ใข!!</button>
</div>

        </form>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
