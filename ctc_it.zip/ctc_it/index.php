<?php 
session_start();
require_once 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration System PDO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css"> 
 
</head>
<style>
    body {
    background-image: url('BB.avif');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    color: #333; /* สีของข้อความ */
}

.container {
    background-color: rgba(223, 222, 220, 0.723); /* สีพื้นหลังของ container */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.515); /* เงาของ container */
}

</style>
<body>

    <div class="container">
        <h3 class="mt-4 text-center">สมัครสมาชิก</h3>
        <hr>
        <form action="signup_db.php" method="post">
            <?php if (isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php 
                        echo htmlspecialchars($_SESSION['error']); 
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php } ?>
            <?php if (isset($_SESSION['success'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?php 
                        echo htmlspecialchars($_SESSION['success']); 
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php } ?>
            <?php if (isset($_SESSION['warning'])) { ?>
                <div class="alert alert-warning" role="alert">
                    <?php 
                        echo htmlspecialchars($_SESSION['warning']); 
                        unset($_SESSION['warning']);
                    ?>
                </div>
            <?php } ?>

            <div class="mb-3">
                <label for="firstname" class="form-label">ชื่อ</label>
                <input type="text" class="form-control" name="firstname" id="firstname" required>
            </div>
            <div class="mb-3">
                <label for="lastname" class="form-label">นามสกุล</label>
                <input type="text" class="form-control" name="lastname" id="lastname" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">อีเมล</label>
                <input type="email" class="form-control" name="email" id="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">รหัสผ่าน</label>
                <input type="password" class="form-control" name="password" id="password" required>
            </div>
            <div class="mb-3">
                <label for="c_password" class="form-label">ยืนยันรหัสผ่าน</label>
                <input type="password" class="form-control" name="c_password" id="c_password" required>
            </div>
            <button type="submit" name="signup" class="btn btn-primary">ลงทะเบียน</button>
        </form>
        <hr>
        <p class="text-center">เป็นสมาชิกแล้วใช่ไหม? <a href="signin.php">เข้าสู่ระบบ</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-ZVP8cE2VnAiZbbkzCG3R8L9mAIk4hAmT3AqH20LkW6Br1TeP9Q4TSBlM6WhX8/pj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-DkQmSRKh3rG8cxVdmH21xH08cdhdHQ9x8B3Be7z+J3kQ1GZT7d1Z7V1KiF+2Rz0h" crossorigin="anonymous"></script>
</body>
</html>
