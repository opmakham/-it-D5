<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<title>ประวัติส่วนตัว</title>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body style="background-image: url(v.png);">
    
  <div class="container-lg mt-3 border">.container-lg</div>
  <div class="container-fluid mt-3">
<div class="row">
    <div class="col p-3 bg-primary text-white">หน้าหลัก</div>
    <div class="col p-3 bg-dark text-white">หน้าถัดไป</div>
    <div class="col p-3 bg-primary text-white">หน้าสุดท้าย</div>
  </div>


<h1 style="color:rgb(26, 207, 207);">ประวัติส่วนตัว</h1>

  
  
        
<img src="k.jpg" alt="Trulli" width="200" height="270">
<h1 style="color:rgb(29, 20, 20);">ประวัติส่วนตัวของฉัน</h1>
<h2 style="color:rgb(209, 36, 171);">ชื่อ-สกุล: นางสาวมาลินี ฉ่ำชูศรี</h2>
<h2 style="color:rgb(209, 36, 171);">แผนก: เทคโนโลยีสารสนเทศ(it)</h2>
<h2 style="color:rgb(209, 36, 171);">อายุ:19 ปี เกิดวันที่ 21/08/2547</h2>
<h2 style="color:rgb(209, 36, 171);">ชื่อเล่น:เปีย กรุ๊บเลือด:A</h2>
<h2 style="color:rgb(209, 36, 171);">เกี่ยวกับฉัน: ส่วนสูง :155mm นํ้าหนัก:52 kg ชอบฟังเพลง เเละเล่นเกมส์</h2>
<h1 style="color:rgb(0, 0, 0);">ที่อยู่ปัจจุบัน</h1>
<h2 style="color:rgb(237, 64, 253);">317/1 บ้านโนนกอก ต.รอบเมือง อ.เมือง จ.ชัยภูมิ</h2>
<h1 style="color:rgb(0, 0, 0);">ช่องทางการติดต่อ</h1>
<h2 style="color:rgb(209, 36, 171);">gmail:oeghso@gmail.com</h2>
<h2 style="color:rgb(209, 36, 171);">facebook:Malinee Chumchusi</h2>
<h2 style="color:rgb(209, 36, 171);">เบอร์โทรศัพท์:0990892251</h2>
<h1 style="color:rgb(6, 3, 8);">ข้อมูลส่วนตัว</h1>
<h2 style="color:rgb(73, 36, 209);">ชื่อบิดา: นายไพโรจน์ ฉ่ำชูศรี อายุ:45ปี </h2>
<h2 style="color:rgb(62, 32, 129);">อาชีพ: เกษตรกร </h2>
<h2 style="color:rgb(14, 16, 179);">ชื่อมารดา: นางสุภรักษณ์ ฉ่ำชูศรี อายุ:45ปี</h2>
<h2 style="color:rgb(50, 18, 190);">อาชีพ: เกษตรกร เบอร์โทรศัพท์:0924482368</h2>
<h1 style="color:rgb(0, 0, 0);">ประวัติศึกษา</h1>
<h2 style="color:rgb(32, 49, 196);">จบจากโรงเรียนบ้านแท่นวิทยา เกรดเฉลี่ย:3.56</h2>
<h1 style="color:rgb(0, 0, 0);">คติประจำใจ</h1>
<h2 style="color:rgb(19, 15, 230);">จงเป็นตัวเองในเวอร์ชันที่ดีที่สุด</h2>
<h1 style="color:rgb(0, 0, 0);">งานอดิเรก</h1>
<h2 style="color:rgb(23, 0, 155);">เล่นเกมส์ ฟังเพลง </h2>
<h1 style="color:rgb(0, 0, 0);">นักศึกษาเลือกเรียนสาขานี้เพราะอะไร เรียนจบอยากทำอาชีพอะไร</h1>
<h2 style="color:rgb(36, 53, 209);">ชอบการออกเเบบ อยากจะเป็นนักออกแบบเว็บหรืออะไรต่างๆ </h2>



</body>
</html>