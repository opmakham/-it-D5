<?php /* *** No Copyright for Education (Free to Use and Edit) *** * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มข้อมูลนักศึกษา</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-image: url('BB.avif');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: rgba(223, 222, 220, 0.723); /* สีพื้นหลังของ container */ 
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.422);
            width: 100%;
            max-width: 600px; /* จำกัดความกว้างของ container */
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .table-striped th, .table-striped td {
            padding: 10px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>เพิ่มข้อมูลนักศึกษา</h2>
        <form action="insertdata.php" method="post" name="tb_d5_67">
            <table class="table-striped">
                <tr>
                    <td>รหัสนักศึกษา:</td>
                    <td><input type="text" class="form-control" name="std_id" required></td>
                </tr>
                <tr>
                    <td>แผนก:</td>
                    <td><input type="text" class="form-control" name="DepartmentID" required></td>
                </tr>
                <tr>
                    <td>คำนำหน้า:</td>
                    <td><input type="text" class="form-control" name="n_title" required></td>
                </tr>
                <tr>
                    <td>ชื่อ:</td>
                    <td><input type="text" class="form-control" name="f_name" required></td>
                </tr>
                <tr>
                    <td>สกุล:</td>
                    <td><input type="text" class="form-control" name="l_name" required></td>
                </tr>
                <tr>
                    <td>ชื่อเล่น:</td>
                    <td><input type="text" class="form-control" name="n_name" required></td>
                </tr>
                <tr>
                    <td>เพศ:</td>
                    <td><input type="text" class="form-control" name="sex" required></td>
                </tr>
                <tr>
                    <td>เบอร์:</td>
                    <td><input type="text" class="form-control" name="number" required></td>
                </tr>
                <tr>
                    <td>e_mail:</td>
                    <td><input type="email" class="form-control" name="e_mail" required></td>
                </tr>
            </table>
            <input type="submit" class="btn btn-primary" value="Insert Data">
        </form>
    </div>
</body>

</html>
